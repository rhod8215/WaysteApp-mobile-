import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hauler-reg',
  templateUrl: './hauler-reg.page.html',
  styleUrls: ['./hauler-reg.page.scss'],
})
export class HaulerRegPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
