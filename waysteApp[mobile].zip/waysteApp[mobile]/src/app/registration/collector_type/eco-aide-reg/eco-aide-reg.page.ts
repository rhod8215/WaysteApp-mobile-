import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eco-aide-reg',
  templateUrl: './eco-aide-reg.page.html',
  styleUrls: ['./eco-aide-reg.page.scss'],
})
export class EcoAideRegPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
