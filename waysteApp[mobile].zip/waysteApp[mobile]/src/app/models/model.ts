export interface Wayste{
    name: string;
    city : string;
    latitude: any;
    longitude:any
}
