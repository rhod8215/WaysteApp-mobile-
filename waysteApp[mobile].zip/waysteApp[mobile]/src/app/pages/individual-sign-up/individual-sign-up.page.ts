import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-individual-sign-up',
  templateUrl: './individual-sign-up.page.html',
  styleUrls: ['./individual-sign-up.page.scss'],
})
export class IndividualSignUpPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
